const products = [
  //Carnes
  { productName: "Lomo Liso Argentino", price: 17.490, img: "img/carnes/carne.jpg", category: "carnes" },
  { productName: "Chuletitas Super Cerdo", price: 4.590, img: "img/carnes/chuletas.jpg", category: "carnes" },
  { productName: "Costillar Super Cerdo 1.8kg", price: 14.990, img: "img/carnes/costillar.jpg", category: "carnes" },
  { productName: "Filetitos Super Pollo", price: 7.290, img: "img/carnes/filetitos.jpg", category: "carnes" },
  { productName: "Pechuga Entera de Pollo", price: 4.590, img: "img/carnes/Pechuga.jpg", category: "carnes" },
  { productName: "Truto Entero de Pollo", price: 2.390, img: "img/carnes/pollo.jpg", category: "carnes" },
  //Lacteos y Fiambreria
  { productName: "Jamon Acaramelado 100gr", price: 1.090, img: "img/Lacteos y Fiambreria/jamon-acaramelado.jpg", category: "lacteos" },
  { productName: "Leche en Polvo Colun 900g", price: 2.232, img: "img/Lacteos y Fiambreria/leche-polvo.jpg", category: "lacteos" },
  { productName: "Leche Entera 1L", price: 6.690, img: "img/Lacteos y Fiambreria/leche.jpg", category: "lacteos" },
  { productName: "Queso Chacra 400g", price: 2.890, img: "img/Lacteos y Fiambreria/queso-chacra.jpg", category: "lacteos" },
  { productName: "Queso Gauda 100gr", price: 1.290, img: "img/Lacteos y Fiambreria/queso.jpg", category: "lacteos" },
  { productName: "Salame ahumado 100g", price: 1.243, img: "img/Lacteos y Fiambreria/salame.jpg", category: "lacteos" },
  //Frutas
  { productName: "Plátano", price: 2.232, img: "img/iconos/imagenes/platano.jpg", category: "frutas" },
  //bebestibles
  { productName: "Coca-Cola", price: 2.232, img: "img/iconos/imagenes/cocacola.jpg", category: "bebestibles" },
  { productName: "caja de corona de 12", price: 2.500, img: "img/iconos/imagenes/packchelas.jpg", category: "bebestibles" },
  { productName: "Cerveza Cristal", price: 3.500, img: "img/iconos/imagenes/cerveza.jpg", category: "bebestibles" },
  //verduras 
  { productName: "Brocoly", price: 1.000, img: "img/iconos/imagenes/brocoly.jpg", category: "verduras" },
  //panaderia
  { productName: "Marraqueta", price: 1.000, img: "img/iconos/imagenes/marraqueta.jpg", category: "panaderia" },
  { productName: "Pan de molde XL", price: 3.500, img: "img/iconos/imagenes/pandemolde.jpg", category: "panaderia" },
];

const displayProducts = (productsToShow) => {
  const shopContent = document.getElementById("shopContent");
  shopContent.innerHTML = "";

  productsToShow.forEach(product => {
    const div = document.createElement("div");
    div.className = "card-products";
    div.innerHTML = `
      <img src="${product.img}" alt="${product.productName}">
      <h3>${product.productName}</h3>
      <p class="price">$ ${product.price.toFixed(3)}</p>
      <button>Agregar al carrito</button>
    `;
    shopContent.appendChild(div);
  });
};

const filterProducts = (category) => {
  if (category === "todos") {
    displayProducts(products);
  } else {
    const filtered = products.filter(product => product.category === category);
    displayProducts(filtered);
  }
};

document.querySelectorAll(".btn-categoria").forEach(button => {
  button.addEventListener("click", () => {
    const categoria = button.getAttribute("data-categoria");
    filterProducts(categoria);
  });
});

// Mostrar todos al cargar
displayProducts(products);


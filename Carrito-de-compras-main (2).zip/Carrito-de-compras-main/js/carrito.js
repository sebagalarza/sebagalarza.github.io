/* Esta lista podría ser reemplazada por la respuesta de un backend */
const merca = [
  {
    id:1,
    nombre: "Coca cola 3L",
    precio: 2500,
  },
  {
    id:2,
    nombre: "Caja de Huevos 30 Unidades",
    precio: 4800,
  },
  {
    id:3,
    nombre: "Malla Limon 10 Unidades",
    precio: 3500,
  },
  {
    id:4,
    nombre: "Pack de Cerverza Corona",
    precio: 3500,
  },
  {
    id:5,
    nombre: "Pan de Molde Ideal XL",
    precio: 2800,
  },
  {
    id:6,
    nombre: "Truto Entero de Pollo 1K",
    precio: 2480,
  },
  {
    id:7,
    nombre: "Manjar Nestle 1k",
    precio: 4340,
  },
  {
    id:8,
    nombre: "Toalla Nova Ultra 26M",
    precio: 1400,
  },
  {
    id:9,
    nombre: "Queso Chacra 400g",
    precio: 2890,
  },
  {
    id:10,
    nombre: "Chuletitas 600g",
    precio: 4590,
  },
  {
    id:11,
    nombre: "Casillero del Diablo 750 ml",
    precio: 4990,
  },
  {
    id:12,
    nombre: "Nescafe Tracicion 170g",
    precio: 5490,
  }
]
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("form-login");

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username === "" || password === "") {
      alert("Por favor, completa todos los campos.");
    } else {
      // Aquí podrías hacer la validación real con backend
      alert("Inicio de sesión exitoso (ejemplo).");
      // window.location.href = "pagina-principal.html"; // Redirigir si deseas
    }
  });
});
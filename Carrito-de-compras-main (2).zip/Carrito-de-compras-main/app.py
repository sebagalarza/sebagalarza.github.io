from flask import Flask

app = Flask(__name__)

@app.route("/")
def home():
    return "Bienvenido al Minimarket"

if __name__ == "__main__":
    app.run(debug=True)



from flask import Flask, render_template, request, redirect, url_for, session, flash
import json
import os
from functools import wraps

app = Flask(__name__)
app.secret_key = 'clave_super_secreta'

# ------------------ UTILIDADES ------------------
DATA_FOLDER = 'data'
USERS_FILE = os.path.join(DATA_FOLDER, 'users.json')
PRODUCTS_FILE = os.path.join(DATA_FOLDER, 'products.json')
PURCHASES_FILE = os.path.join(DATA_FOLDER, 'purchases.json')
CART_FILE = os.path.join(DATA_FOLDER, 'cart.json')


def load_json(path):
    if not os.path.exists(path):
        return []
    with open(path, 'r') as f:
        return json.load(f)


def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=4)


# ------------------ DECORADORES ------------------
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session:
            flash('Inicia sesión para continuar.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user' not in session or not session['user'].get('is_admin'):
            flash('Acceso solo para administradores.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated


# ------------------ RUTAS ------------------
@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        is_admin = 'is_admin' in request.form

        users = load_json(USERS_FILE)
        if any(u['username'] == username for u in users):
            flash('Usuario ya existe.', 'danger')
            return redirect(url_for('register'))

        users.append({'username': username, 'password': password, 'is_admin': is_admin})
        save_json(USERS_FILE, users)
        flash('Registro exitoso. Inicia sesión.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        users = load_json(USERS_FILE)
        user = next((u for u in users if u['username'] == username and u['password'] == password), None)
        if user:
            session['user'] = user
            flash(f'Bienvenido {username}', 'success')
            return redirect(url_for('index'))
        else:
            flash('Credenciales incorrectas.', 'danger')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('Sesión cerrada.', 'info')
    return redirect(url_for('index'))


@app.route('/products')
def products():
    products = load_json(PRODUCTS_FILE)
    return render_template('products.html', products=products)


@app.route('/admin/products/add', methods=['GET', 'POST'])
@admin_required
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        price = float(request.form['price'])
        stock = int(request.form['stock'])

        products = load_json(PRODUCTS_FILE)
        products.append({'id': len(products)+1, 'name': name, 'price': price, 'stock': stock})
        save_json(PRODUCTS_FILE, products)
        flash('Producto agregado.', 'success')
        return redirect(url_for('products'))

    return render_template('add_product.html')


@app.route('/cart')
@login_required
def view_cart():
    cart = load_json(CART_FILE)
    user_cart = [item for item in cart if item['user'] == session['user']['username']]
    products = load_json(PRODUCTS_FILE)
    total = sum(item['quantity'] * next(p['price'] for p in products if p['id'] == item['product_id']) for item in user_cart)
    return render_template('cart.html', cart=user_cart, total=total)


@app.route('/cart/add/<int:product_id>', methods=['POST'])
@login_required
def add_to_cart(product_id):
    quantity = int(request.form['quantity'])
    cart = load_json(CART_FILE)
    user = session['user']['username']

    for item in cart:
        if item['user'] == user and item['product_id'] == product_id:
            item['quantity'] += quantity
            break
    else:
        cart.append({'user': user, 'product_id': product_id, 'quantity': quantity})

    save_json(CART_FILE, cart)
    flash('Producto añadido al carrito.', 'success')
    return redirect(url_for('view_cart'))


@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    cart = load_json(CART_FILE)
    products = load_json(PRODUCTS_FILE)
    purchases = load_json(PURCHASES_FILE)
    user = session['user']['username']

    user_cart = [item for item in cart if item['user'] == user]
    if not user_cart:
        flash('Tu carrito está vacío.', 'warning')
        return redirect(url_for('view_cart'))

    total = 0
    items = []
    for item in user_cart:
        product = next((p for p in products if p['id'] == item['product_id']), None)
        if product:
            subtotal = product['price'] * item['quantity']
            total += subtotal
            items.append({"name": product['name'], "price": product['price'], "quantity": item['quantity'], "subtotal": subtotal})

    purchases.append({"user": user, "items": items, "total": total})
    cart = [item for item in cart if item['user'] != user]  # limpiar carrito

    save_json(PURCHASES_FILE, purchases)
    save_json(CART_FILE, cart)

    flash('Compra realizada con éxito.', 'success')
    return redirect(url_for('purchase_history'))


@app.route('/purchases')
@login_required
def purchase_history():
    purchases = load_json(PURCHASES_FILE)
    user_purchases = [p for p in purchases if p['user'] == session['user']['username']]
    return render_template('purchase_history.html', purchases=user_purchases)


if __name__ == '__main__':
    os.makedirs(DATA_FOLDER, exist_ok=True)
    for file in [USERS_FILE, PRODUCTS_FILE, PURCHASES_FILE, CART_FILE]:
        if not os.path.exists(file):
            save_json(file, [])
    app.run(debug=True) 